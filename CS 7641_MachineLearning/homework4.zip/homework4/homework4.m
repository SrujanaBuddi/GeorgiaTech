function homework4
% This is the main function for homework 4
% You are asked to plugin your implementation for algorithm, the argument is the q



clear;close all;

load sp500;

algorithm(0.7)

algorithm(0.9)

end
