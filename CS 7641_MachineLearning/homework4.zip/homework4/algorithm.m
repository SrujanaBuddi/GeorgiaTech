function prob = algorithm(q)

% plot and return the probability



end
